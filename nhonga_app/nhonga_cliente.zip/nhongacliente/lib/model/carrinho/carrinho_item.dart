import 'package:nhonga_app/model/produto/produto.dart';

class CarrinhoItem {
  final Produto produto;

  CarrinhoItem({required this.produto});
}
