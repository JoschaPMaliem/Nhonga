
class ListaCliente {

  

  /*
    final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Collection reference
  CollectionReference get _clientsCollection => _firestore.collection('clients');

  // Add a client
  Future<void> addClient(Client client) {
    return _clientsCollection.doc(client.id).set(client.toMap());
  }

  // Get all clients
  Stream<List<Client>> getClients() {
    return _clientsCollection.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return Client.fromMap(doc.data() as Map<String, dynamic>);
      }).toList();
    });
  }

  // Update a client
  Future<void> updateClient(Client client) {
    return _clientsCollection.doc(client.id).update(client.toMap());
  }

  // Delete a client
  Future<void> deleteClient(String id) {
    return _clientsCollection.doc(id).delete();
  }
}

*/
  
}


