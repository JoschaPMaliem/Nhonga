import 'package:nhonga_app/model/produto/produto.dart';

class List_Produto {
  final List<Produto> produtosLista = [
    Produto(

        id: '1',
        nome: 'Iphone 15',
        vendedor: 'John Mateus',
        imagem:
            'https://www.imagineonline.store/cdn/shop/files/iPhone_15_Pro_Max_Natural_Titanium_PDP_Image_Position-1__en-IN_817ead95-bff3-4129-866d-3f87976e8be2.jpg?v=1694759321',
        preco: '500.00',
        estado: 'Disponível',
        localizacao: 'Maputo'),

    Produto(
      id: '1',
        nome: 'Airpods',
        vendedor: 'John Mateus',
        imagem:
            'https://www.zdnet.com/a/img/resize/23eeb2449242a2e1c5ce926e9e3e785752c13e3d/2023/09/10/e2624a38-8a73-4b30-861d-315a640fb28e/airpods-2nd-gen.jpg?auto=webp&fit=crop&height=1200&width=1200',
        preco: '500.00',
        estado: 'Disponível',
        localizacao: 'Maputo'),

    Produto(
      id: '1',
        nome: 'HP Pavilion',
        vendedor: 'John Mateus',
        imagem:
            'https://www.hp.com/gb-en/shop/Html/Merch/Images/c06723377_1750x1285.jpg',
        preco: '500.00',
        estado: 'Disponível',
        localizacao: 'Maputo'),

    Produto(
      id: '1',
        nome: 'Bolsa gucci',
        vendedor: 'John Mateus',
        imagem:
            'https://www.net-a-porter.com/variants/images/15546005222271485/in/w2000_a3-4_q60.jpg',
        preco: '500.00',
        estado: 'Disponível',
        localizacao: 'Maputo'),

    Produto(
      id: '1',
        nome: 'Camisola ',
        vendedor: 'John Mateus',
        imagem:
            'https://studios-tc.com/wp-content/uploads/2021/10/oversize-hoodie-black-back.jpg',
        preco: '500.00',
        estado: 'Disponível',
        localizacao: 'Maputo'),

    Produto(
      id: '1',
        nome: 'Casa T3',
        vendedor: 'John Mateus',
        imagem:
            'https://i.pinimg.com/736x/6b/23/4c/6b234cee5f1a9c26d7e1f7901d77e6db.jpg',
        preco: '500.000.00',
        estado: 'Disponível',
        localizacao: 'Maputo'),

    


    

    
  ];
}
