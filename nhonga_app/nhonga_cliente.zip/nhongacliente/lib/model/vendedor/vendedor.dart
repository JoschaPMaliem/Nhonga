class Vendedor {
  String id;
  String nome;
  String email;
  String telefone;
  String password;

  Vendedor(
      {required this.id,
      required this.nome,
      required this.email,
      required this.telefone,
      required this.password});
}
